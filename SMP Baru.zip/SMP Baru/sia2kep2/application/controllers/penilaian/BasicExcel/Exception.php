<?php

namespace BasicExcel;

Class Exception extends \Exception {
    
}